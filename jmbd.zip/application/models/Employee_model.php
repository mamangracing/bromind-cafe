<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Employee_model extends CI_Model
{
    function get_employee()
    {
        $this->db->where('role_id !=', 1);
        $employe = $this->db->get('user')->result_array();
        return $employe;
    }

    function del_user($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('user');
    }

    function get_leaderaccount()
    {
        $leader = $this->db->query('SELECT * FROM user WHERE role_id!=2 AND email!="mahapatih.anton@gmail.com"')->result_array();
        return $leader;
    }
}