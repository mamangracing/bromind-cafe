//mendapatkan target produk
const attToCartBtn = document.getElementsByClassName('ShoppingCart');
let items = [];

for(let i = 0; i<attToCartBtn.length; i++){
	attToCartBtn[i].addEventListener('click',function(e){
		
		if(typeof(Storage) !== 'undefined'){

			let item = {
				image:attToCartBtn[i].parentElement.parentElement.parentElement.parentElement.parentElement.children[0].children[0].src,
				price:parseInt(attToCartBtn[i].parentElement.parentElement.parentElement.children[1].innerText),
				name:attToCartBtn[i].parentElement.parentElement.parentElement.children[0].innerText,
				no:parseInt(attToCartBtn[i].parentElement.parentElement.children[0].children[0].children[1].children[0].children[1].value),
				id:parseInt(attToCartBtn[i].parentElement.parentElement.children[0].children[0].children[1].children[0].children[2].value)
			}

			// localStorage.setItem('product_list',JSON.stringify(item));

			if(JSON.parse(localStorage.getItem('items')) === null){
				items.push(item);
				localStorage.setItem("items",JSON.stringify(items));
				window.location.reload();
				
			}else{

				const localItems = JSON.parse(localStorage.getItem('items'));

				localItems.map(data=>{
					if(item.name == data.name){
						item.no = data.no + 1;
						console.log(item);
					}else{
						items.push(data);
					}
				});
				items.push(item);
				localStorage.setItem('items',JSON.stringify(items));
				window.location.reload();
			}

		}else{
			alert('Local storage not working in your browser');
		}
	});
}

let iconShoppingp=document.querySelector('.iconShopping div');
let no = 0;
JSON.parse(localStorage.getItem('items')).map(data=>{
	no = no + data.no;
})
iconShoppingp.innerHTML = no;

let iconShoppingd=document.querySelector('.iconShopping-dekstop div');
let number = 0;
JSON.parse(localStorage.getItem('items')).map(data=>{
	number = number + data.no;
})
iconShoppingd.innerHTML = number;
